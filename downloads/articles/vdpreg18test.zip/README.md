VDP Register 18 test
====================

Copyright 2022 Laurens Holst

Project information
-------------------

  * Author: Laurens Holst <laurens@grauw.nl>
  * Site: <http://map.grauw.nl/articles/vdp_guide.php>
  * License: Simplified BSD License

Test program of r#18 interaction with copy commands and the display.

This test program cycles through four different stages:

1. Full screen copy while r#18 horizontal offset decrements, sprites enabled.
2. Full screen copy while r#18 horizontal offset increments, sprites enabled.
3. Full screen copy while r#18 horizontal offset decrements, sprites disabled.
4. Full screen copy while r#18 horizontal offset increments, sprites disabled.
