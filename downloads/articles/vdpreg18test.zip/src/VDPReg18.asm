;
; Test corruption when using r#18 during copy commands.
;
CALSLT: equ 001CH
CHGMOD: equ 005FH
FORCLR: equ 0F3E9H
BAKCLR: equ 0F3EAH
BDRCLR: equ 0F3EBH
EXPTBL: equ 0FCC1H

VDP_PORT_0: equ 98H
VDP_PORT_1: equ 99H
VDP_PORT_2: equ 9AH
VDP_PORT_3: equ 9BH

VDP_READ: equ 00000000B
VDP_WRITE: equ 01000000B
VDP_REGISTER: equ 10000000B

VDP_MIRROR_0: equ 0F3DFH
VDP_MIRROR_8: equ 0FFE7H - 8
VDP_MIRROR_25: equ 0FFFAH - 25

OPCODE_NOP: equ 00H
OPCODE_CPL: equ 2FH

	org 100H

Main:
	ld a,15
	ld (FORCLR),a
	ld a,4
	ld (BAKCLR),a
	ld a,4
	ld (BDRCLR),a
	ld a,5
	ld iy,(EXPTBL - 1)
	ld ix,CHGMOD
	call CALSLT

	ld a,(VDP_MIRROR_8 + 9)
	and 11111101B
	ld (VDP_MIRROR_8 + 9),a
	di
	out (VDP_PORT_1),a
	ld a,9 | VDP_REGISTER
	ei
	out (VDP_PORT_1),a

	ld b,16
	ld ix,fillBar
	ld (ix + VDPCommand.dy + 1),1
FillLoop1:
	push bc
	ld a,16
	sub b
	ld c,a
	add a,a
	add a,a
	add a,a
	add a,a
	ld (ix + VDPCommand.dx),a
	or c
	ld (ix + VDPCommand.color),a
	call VDPCommand_Execute
	pop bc
	djnz FillLoop1

	ld b,16
	ld ix,fillBar
	ld (ix + VDPCommand.dy + 1),2
FillLoop2:
	push bc
	ld a,16
	sub b
	ld c,a
	add a,a
	add a,a
	add a,a
	add a,a
	ld (ix + VDPCommand.dx),a
	or c
	cpl
	ld (ix + VDPCommand.color),a
	call VDPCommand_Execute
	pop bc
	djnz FillLoop2

	ld ix,copyToPage0
	ld iy,ModifyR18.reverse
CopyLoop:
	ld a,(VDP_MIRROR_8 + 8)
	and 11111101B
	ld (VDP_MIRROR_8 + 8),a
	di
	out (VDP_PORT_1),a
	ld a,8 | VDP_REGISTER
	ei
	out (VDP_PORT_1),a

	ld (ix + VDPCommand.sy + 1),1
	ld (iy),OPCODE_NOP
	call CopyAndTwiddleR18
	ld (ix + VDPCommand.sy + 1),2
	ld (iy),OPCODE_CPL
	call CopyAndTwiddleR18

	ld a,(VDP_MIRROR_8 + 8)
	or 00000010B
	ld (VDP_MIRROR_8 + 8),a
	di
	out (VDP_PORT_1),a
	ld a,8 | VDP_REGISTER
	ei
	out (VDP_PORT_1),a

	ld (ix + VDPCommand.sy + 1),1
	ld (iy),OPCODE_NOP
	call CopyAndTwiddleR18
	ld (ix + VDPCommand.sy + 1),2
	ld (iy),OPCODE_CPL
	call CopyAndTwiddleR18
	jr CopyLoop

CopyAndTwiddleR18: PROC
	halt
	call VDPCommand_Execute
	ld b,100H
Loop:
	push bc
	call ModifyR18
	pop bc
	djnz Loop
	ld b,60
Pause:
	halt
	djnz Pause
	ret
	ENDP

ModifyR18: PROC
	ld b,0
	ld c,VDP_PORT_1
	ld d,18 | VDP_REGISTER
	ld e,0FH
Loop:
	ld a,b
	and e
reverse: equ $
	cpl
	di
	out (c),a
	ei
	out (c),d
	djnz Loop
	ret
	ENDP

;
	INCLUDE "VDPCommand.asm"

fillBar:
	VDPCommand 0, 0, 0, 0, 16, 212, 0FFH, 0, VDPCommand_HMMV

copyToPage0:
	VDPCommand 0, 0, 0, 0, 256, 212, 0, 0, VDPCommand_LMMM | VDPCommand_IMP
